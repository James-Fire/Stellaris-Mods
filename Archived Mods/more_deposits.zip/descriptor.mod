name="More Orbital Deposits"
archive="more_deposits.zip"
tags={
	"Balance"
	"Economy"
	"Galaxy Generation"
}
picture="more orbital deposits.jpg"
remote_file_id="1334480360"
supported_version="2.2.5"
