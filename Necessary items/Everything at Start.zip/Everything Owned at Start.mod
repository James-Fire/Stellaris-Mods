name="Everything Owned at Start"
tags={
}
supported_version="2.8.*"
path="C:/Users/godis/Documents/Paradox Interactive/Stellaris/mod/Everything Owned at Start"